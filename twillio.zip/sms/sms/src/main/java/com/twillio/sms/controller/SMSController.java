package com.twillio.sms.controller;

import com.twilio.rest.api.v2010.account.Message;

import com.twillio.sms.dto.OTPRequest;
import com.twillio.sms.service.OtpGenerate;
import com.twillio.sms.service.SMSService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static com.twillio.sms.constant.Constant.OTP_MESSAGE;

@RestController
@RequestMapping("/messageService/")
@Slf4j
public class SMSController {
    @Autowired
    private final SMSService smsService;
    @Autowired
    private final OtpGenerate otpGenerate;

    public SMSController(SMSService smsService, OtpGenerate otpGenerate) {
        this.smsService = smsService;
        this.otpGenerate = otpGenerate;
    }

    @PostMapping("sms/otp")
    public ResponseEntity<Object> sendOtp(@RequestBody OTPRequest request) throws Exception {
       // int otp = otpGenerate.getOtpCode();
        int otp =0;
     Message twilioMessage = (Message) smsService.sendOtp(request.getMobileNumber(),OTP_MESSAGE.replace("<otp>",Integer.toString(otp)));
       // Message twilioMessage = (Message) smsService.sendOtp(request.getMobileNumber());
        log.info("Twilio Response : {}", twilioMessage.getStatus());
        if (twilioMessage.getStatus().toString().equals("queued")) {
            return new ResponseEntity<Object>(HttpStatus.OK);
        } else {
            return new ResponseEntity<Object>(HttpStatus.EXPECTATION_FAILED);
        }
    }
}
