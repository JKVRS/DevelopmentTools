package com.twillio.sms.service;

import com.twilio.Twilio;
import com.twilio.exception.ApiException;

import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import com.twillio.sms.configratation.TwillioConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SMSServiceImpl implements SMSService{

    @Autowired
    private final TwillioConfig twillioConfig;

    public SMSServiceImpl(TwillioConfig twillioConfig) {
        this.twillioConfig = twillioConfig;
    }

    @Override
    public Object sendOtp(String mobileNumber, String message) throws Exception {
        try {
            if (isPhoneNumberValid(mobileNumber)) {
                PhoneNumber to = new PhoneNumber(mobileNumber);
                PhoneNumber from = new PhoneNumber(twillioConfig.getTrialNumber());
                // initiate twillio
                Twilio.init(twillioConfig.getAccountSid(), twillioConfig.getAuthToken());
                return Message.creator(to,from,message).create();
            } else {
                throw new IllegalArgumentException(
                        "Phone number [" + mobileNumber + "] is not a valid number"
                );
            }
        } catch (ApiException exception) {
            throw new Exception(exception.getMessage());
        }
    }

//    public Object sendOtp(String recipientPhoneNumber, String otpCode) {
//       return Message.creator(new PhoneNumber(recipientPhoneNumber), new PhoneNumber(twilioPhoneNumber),
//                        "Your OTP code is: " + otpCode)
//                .create(twilioRestClient);
//    }
    private boolean isPhoneNumberValid(String mobileNumber) {
        // TODO: Implement phone number validator
        return true;
    }
}
