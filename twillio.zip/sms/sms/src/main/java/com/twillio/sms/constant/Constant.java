package com.twillio.sms.constant;

public class Constant {
    public static final String OTP_MESSAGE ="hi vijay garg " +
            "  "+ "<otp>";
    public static final String OTP_SEND_ISSUE="OTP can not be send";
}
