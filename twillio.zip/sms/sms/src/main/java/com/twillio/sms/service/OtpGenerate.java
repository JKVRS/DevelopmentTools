package com.twillio.sms.service;

import org.springframework.stereotype.Service;

@Service
public class OtpGenerate {

    public int getOtpCode(){
        long currentTimeMillis = System.currentTimeMillis();

        // Convert to string
        String strTimeMillis = Long.toString(currentTimeMillis);

        // Use the last 6 digits as the OTP
        String otp = strTimeMillis.substring(strTimeMillis.length() - 6);
        return Integer.parseInt(otp);

    }
}
