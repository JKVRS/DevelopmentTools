package com.twillio.sms.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OTPRequest {

    private String mobileNumber;
    private String message;
}
