package com.twillio.sms.service;

public interface SMSService {

    Object sendOtp(String mobileNumber, String message) throws Exception;
}
